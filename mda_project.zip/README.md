# Mechanistic Data Attribution (MDA) — Toy Induction Model

Reproduction of the MDA pipeline (EK-FAC-based influence functions) on a toy
2-layer attention-only transformer trained on a synthetic induction task.

## Layout

```
mda_project/
├── config.py                    # shared constants (task, model, EK-FAC hyperparams)
├── data.py                      # generate_batch: synthetic [prefix, prefix] task
├── model.py                     # build_model: HookedTransformer builder
├── induction_metrics.py         # compute_induction_scores: per-head induction strength
├── mda/
│   ├── hooks.py                 # QKVOActivationCache + setup_qkvo_hooks
│   ├── ekfac.py                 # EKFACQKVOHead: A/S accumulation, eigendecomp, IHVP
│   ├── stage1.py                # run_ekfac_stage1: fits EK-FAC (A/S, then Lambda)
│   ├── probe.py                 # compute_probe_gradient: induction-copying probe
│   └── scoring.py               # score_training_samples: influence scoring
└── scripts/
    ├── train.py                       # basic training loop w/ induction acc/score logging
    ├── train_with_checkpoints.py      # training loop with dense (every-5-step) checkpointing
    └── run_mda.py                     # full pipeline: EK-FAC → probe → IHVP → scoring → plots
```

## Usage

Train a model:

```bash
python scripts/train_with_checkpoints.py
```

Run the MDA pipeline (edit `load_model()` in `scripts/run_mda.py` to load your
trained checkpoint):

```bash
python scripts/run_mda.py
```

## Requirements

- torch
- transformer_lens
- numpy
- matplotlib
